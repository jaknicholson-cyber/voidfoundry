// VOIDFOUNDRY — deterministic, constraint-aware original fan-lore generator.
// Canon references are bounded; invented history is never represented as Games Workshop canon.
export const fields = [
  {key:'geneLine', label:'Gene-seed lineage', options:['Random','Ultramarines','Imperial Fists','Blood Angels','Dark Angels','White Scars','Space Wolves','Iron Hands','Salamanders','Raven Guard','Unknown']},
  {key:'founding', label:'Founding', options:['Random','Ultima Founding','Later Founding','Unrecorded Founding','Second Founding (speculative)']},
  {key:'worldType', label:'Chapter home', options:['Random','Death World','Hive World','Feudal World','Feral World','Ice World','Desert World','Jungle World','Ocean World','Fleet-based']},
  {key:'armour', label:'Primary armour', options:['Random','Oxide Red','Obsidian','Bone White','Deep Teal','Storm Blue','Verdigris','Ash Grey','Royal Purple','Burnished Gold','Sable Green']},
  {key:'doctrine', label:'Combat doctrine', options:['Random','Siege Warfare','Shock Assault','Stealth & Infiltration','Armoured Warfare','Ranged Firepower','Rapid Strikes','Void Warfare']},
  {key:'codex', label:'Codex adherence', options:['Random','Strict','Broadly Compliant','Unorthodox']},
  {key:'character', label:'Chapter temperament', options:['Random','Stoic','Zealous','Secretive','Honour-bound','Ruthless','Pragmatic','Scholarly']}
];
export const palette = {
 'Oxide Red': {base:'#772e32', light:'#af6260', shadow:'#2a1018', trim:'#c3a57c', soft:'#a85c5d'},
 'Obsidian': {base:'#22262e',light:'#626b74',shadow:'#0c0d12',trim:'#c3a57c',soft:'#8c9299'},
 'Bone White': {base:'#c7bdab',light:'#f0e7cf',shadow:'#6a625c',trim:'#9c693d',soft:'#dacfb9'},
 'Deep Teal':{base:'#276369',light:'#6caba5',shadow:'#102b32',trim:'#d3b486',soft:'#7caca7'},
 'Storm Blue':{base:'#2e476e',light:'#7395b8',shadow:'#141c36',trim:'#c3a57c',soft:'#748fac'},
 'Verdigris':{base:'#53745c',light:'#9aaa8c',shadow:'#233929',trim:'#d1b36c',soft:'#9bac91'},
 'Ash Grey':{base:'#606a6d',light:'#aebbb9',shadow:'#202d30',trim:'#d2ad72',soft:'#b0b3ab'},
 'Royal Purple':{base:'#4e395e',light:'#9280a0',shadow:'#241a33',trim:'#c9a879',soft:'#9384a3'},
 'Burnished Gold':{base:'#977649',light:'#e3ba71',shadow:'#44301c',trim:'#d7dfda',soft:'#d1b17a'},
 'Sable Green':{base:'#314b3a',light:'#77997e',shadow:'#14251d',trim:'#c3aa74',soft:'#789881'}
};
const parent = {
 'Ultramarines': {note:'Descended from Roboute Guilliman’s gene-line, a lineage well represented among loyalist successor Chapters.',seed:'stable',practice:'scholastic record-keeping and disciplined command councils'},
 'Imperial Fists': {note:'The Imperial Fists gene-line is associated with stoicism and tenacity; certain zygote deficiencies are established lore.',seed:'stable',practice:'oaths of endurance and ritualised bastion-keeping'},
 'Blood Angels': {note:'The Blood Angels bloodline carries the Red Thirst and the Black Rage; successors must contend with these inherited curses.',seed:'thirst',practice:'the vigil of the crimson chalice and watch over afflicted brothers'},
 'Dark Angels': {note:'Successors of the Dark Angels have their own traditions, often with inner circles and guarded records.',seed:'secret',practice:'nested circles of initiation and sealed confessions'},
 'White Scars': {note:'The White Scars stem from Jaghatai Khan’s Legion and are celebrated for mobility, initiative and fierce independence.',seed:'stable',practice:'sung epics of the open hunt and mounted trials'},
 'Space Wolves': {note:'Space Wolves successors are rare historically, but Primaris-era successor Chapters such as the Wolfspear are established.',seed:'wolf',practice:'clan-fellowship and saga recitations'},
 'Iron Hands': {note:'The Iron Hands descend from Ferrus Manus and commonly embrace extensive bionics and the primacy of iron discipline.',seed:'stable',practice:'rites of calibration and the measured sacrifice of flesh'},
 'Salamanders': {note:'The Salamanders’ gene-line is linked to Vulkan and is associated with distinctive pigmentation in certain environments.',seed:'stable',practice:'craft-oaths, flame vigils and protection of the helpless'},
 'Raven Guard': {note:'The Raven Guard descend from Corvus Corax and are renowned for subterfuge and precision warfare.',seed:'stable',practice:'the silent watch and trials of unseen passage'},
 'Unknown': {note:'This Chapter’s progenitor is unconfirmed in accessible Imperial records; suggestions of forbidden ancestry remain rumour, not fact.',seed:'unknown',practice:'gene-seed examination and guarded archive rites'}
};
const worldProfiles = {
 'Death World':{tag:'feral, lethal ecosystem',biome:'razor-edged mesas and forests of predatory silica reeds',resource:'bone-glass',tribes:'hunting enclaves',trial:'cross the Black Meridian without fire or an escort',wild:['glassmaw stalker','carrion moth','hollowback drake'],scene:'spires'},
 'Hive World':{tag:'hive continent',biome:'stacked manufactoria beneath permanent thunderclouds',resource:'reactor ash',tribes:'underhive guilds',trial:'return from the locked underworks bearing a witness-seal',wild:['ferric rat','vent-asp','ashwing scavenger'],scene:'hive'},
 'Feudal World':{tag:'feudal protectorate',biome:'wind-battered fiefs, frost-silver rivers and cyclopean keeps',resource:'black iron',tribes:'oathbound houses',trial:'stand the Night Watch alone beside the old beacon',wild:['crown-hart','storm gryph','moor wyrm'],scene:'spires'},
 'Feral World':{tag:'tribal frontier',biome:'rolling stone savannahs threaded with volcanic fault lines',resource:'red flint',tribes:'nomadic kinbands',trial:'track a dusk-strider for seven nights without killing it',wild:['dusk-strider','thornback','pale jackal'],scene:'desert'},
 'Ice World':{tag:'frozen deathscape',biome:'immense blue glaciers and fjords beneath an endless aurora',resource:'glacier iron',tribes:'icebound clans',trial:'carry an ember across the White Expanse before it dies',wild:['rimefang','ice-leviathan','shiverwing'],scene:'ice'},
 'Desert World':{tag:'sun-scoured wastes',biome:'vast dunes, salt mirrors and buried cities of cyclopean stone',resource:'sunstone',tribes:'water-keeper caravans',trial:'find the lost well of the First Pilgrims by stars alone',wild:['sandmantle','dune reaver','salt viper'],scene:'desert'},
 'Jungle World':{tag:'canopy wilderness',biome:'towering rainforests and rivers lit by luminous fungal tides',resource:'ghostwood',tribes:'canopy settlements',trial:'descend to the root-dark and return with a living seed',wild:['mireclaw','canopy basilisk','lantern-wing'],scene:'jungle'},
 'Ocean World':{tag:'archipelago world',biome:'violent oceans scattered with basalt islands and drowned temples',resource:'void-pearl',tribes:'reef citadels',trial:'swim the Undertow Channel and bring back a tide-stone',wild:['abyssal wyrm','reef-lurker','stormray'],scene:'ocean'},
 'Fleet-based':{tag:'fleet-bound Chapter',biome:'the deck-cities of its wandering fortress-monastery',resource:'reliquary bronze',tribes:'shipborn clans',trial:'navigate a darkened maintenance maze during a simulated hull breach',wild:['bilge prowler','voidmoth','cargo-deck serpent'],scene:'void'}
};
const doctrineText = {
 'Siege Warfare':['methodical encirclement and layered fieldworks','siege cadres, breacher squads and artillery spotters','break enemy fortresses without surrendering the lives of the unprotected'],
 'Shock Assault':['brutal close-range breach assaults','assault brethren, boarding shields and decisive reserve strikes','sever command structures before the enemy can reform'],
 'Stealth & Infiltration':['reconnaissance and simultaneous precision strikes','Phobos-equipped vanguard teams and silent observers','leave the enemy blind before the first shot is fired'],
 'Armoured Warfare':['integrated infantry and mechanised spearheads','vehicle crews, Techmarines and mobile reserve lines','use concentrated armour to split and isolate strongpoints'],
 'Ranged Firepower':['interlocking fire lanes and disciplined target priority','fire-support squads, marksmen and auspex hunters','attrit dangerous threats at range before closing for the final purge'],
 'Rapid Strikes':['rapid redeployment and hit-and-withdraw warfare','outriders, jump-pack formations and fast attack columns','strike where a relief force cannot arrive in time'],
 'Void Warfare':['shipboard actions and void-station interdiction','boarding cadres, void-hardened assault squads and strike cruisers','take intact the bridges, reactors and munition holds of hostile ships']
};
const adjectives=['Ashen','Umbral','Argent','Sable','Penumbral','Iron','Dusk','Vesper','Obsidian','Cinder','Hollow','Storm','Pale','Void','Gloam','Brazen','Silent','Fell','Nocturne','Crimson'];
const nouns=['Wardens','Covenant','Sentinels','Votaries','Harbingers','Lancers','Exiles','Paladins','Reclaimers','Knights','Watchers','Praetors','Hounds','Lamenters','Oathkeepers','Pilgrims','Custodians','Sons','Reavers','Templars'];
const first=['Kael','Tiber','Soren','Varek','Merek','Damar','Acast','Orpheo','Rhyse','Caedmon','Talon','Vorian','Osric','Bastan','Iscor','Malvek','Tarak','Valen','Garren','Severin'];
const last=['Voss','Thane','Korr','Drevan','Kast','Halvek','Atron','Sath','Morda','Valcor','Rhune','Keir','Ardent','Serac','Malkor','Vel','Kordane','Oris'];
const worldsA=['Khar','Vel','Nox','Dra','Var','Morn','Thyr','Astra','Cind','Sere','Oss','Cal','Vey','Ghar','Oris','Ech','Reth','Ith'];
const worldsB=['axis','os','eth','aris','ara','ion','un','ax','oria','eris','ad','os Prime','eus','um'];
const fortressNames=['The Last Beacon','The Night Bastion','The Crucible Keep','The Iron Reliquary','The House of Unbroken Vows','The Sepulchre of Stars'];
const relicNames=['The Severance Blade','The Iron Testament','The First Ember','The Argent Eye','The Vigil Spear','The Shard of Oaths'];
const threatNames=['the Brazen Reavers','the Choir of Flies','the Pale Circuit','the Bone-sunder Waaagh!','the Hadran Tyrant Fleet','the Shrouded Covenant','the Red Scar Corsairs'];
export function rng(seed){let s=seed>>>0; return ()=>{s=(s+0x6D2B79F5)|0;let t=Math.imul(s^(s>>>15),1|s);t^=t+Math.imul(t^(t>>>7),61|t);return ((t^(t>>>14))>>>0)/4294967296;};}
function pick(r,a){return a[Math.floor(r()*a.length)];}
function roman(i){return ['I','II','III','IV','V','VI','VII','VIII','IX','X'][i-1]||String(i);}
export function blankPrefs(){return Object.fromEntries(fields.map(f=>[f.key,'Random']));}
export function generateChapter(prefs={},seed=Math.floor(Math.random()*4294967295)){
 const r=rng(seed); const settings={};
 for(const f of fields){let selection=prefs[f.key]||'Random'; const options=f.options.slice(1).filter(v=>!(f.key==='geneLine' && v==='Unknown' && r()<0.5));settings[f.key]=selection==='Random'?pick(r,options):selection;}
 // A Second Founding chapter predates Primaris. It is explicitly speculative as an original Second Founding Chapter.
 if(settings.geneLine==='Space Wolves' && settings.founding==='Second Founding (speculative)' && prefs.founding==='Random') settings.founding='Ultima Founding';
 const wp=worldProfiles[settings.worldType], dt=doctrineText[settings.doctrine];
 const base=pick(r,adjectives)+' '+pick(r,nouns); const name=base;
 const worldName=settings.worldType==='Fleet-based'?'The Pilgrim Armada':pick(r,worldsA)+pick(r,worldsB);
 const col=palette[settings.armour];
 const sigil=pick(r,['spire','blade','star','chalice','wing','flame','skull','gate']);
 const accent=pick(r,['ivory','crimson','gold']);
 const master='Asterion '+pick(r,last); const captain=pick(r,first)+' '+pick(r,last); const chaplain=pick(r,first)+' '+pick(r,last);
 const century=pick(r,['M37','M38','M39','M40']);
 let founded= settings.founding==='Ultima Founding'?'Early M42':settings.founding==='Second Founding (speculative)'?'Early M31':settings.founding==='Unrecorded Founding'?'Founding records sealed':`${century} (precise date disputed)`;
 const distant= settings.founding==='Ultima Founding'?'during the Indomitus-era expansion':settings.founding==='Second Founding (speculative)'?'in the turbulent aftermath of the Second Founding':settings.founding==='Unrecorded Founding'?'under a now-sealed Adeptus Terra writ':'to secure vulnerable Imperial holdings';
 const flaws=parent[settings.geneLine];
 const culture=`The ${name} are ${settings.character.toLowerCase()} warriors who regard ${pick(r,['the keeping of vows','duty to the forgotten','remembrance of the fallen','the preservation of memory','the patient mastery of fear'])} as the highest measure of service. Their traditions centre on ${flaws.practice}. Every oath is struck into thin tablets of ${wp.resource}; those of fallen battle-brothers are interred in the Chapter’s Hall of Witnesses.`;
 const worldStory= settings.worldType==='Fleet-based'?`Without a single recruiting world, the Chapter draws aspirants from ${wp.tribes} across the fleet and Imperial protectorates along its patrol routes. Its fortress-monastery, ${pick(r,fortressNames)}, travels within the vast battle barge at the centre of its armada.`:`${worldName} is a ${wp.tag} where ${wp.biome}. The ${wp.tribes} survive by strict communal vows, and their austere customs have shaped the Chapter's identity. High above the largest settlement stands ${pick(r,fortressNames)}, the fortress-monastery from which its wars are directed.`;
 const wildlife=wp.wild.map((a,i)=>({name:a.split(' ').map(w=>w[0].toUpperCase()+w.slice(1)).join(' '),description:[`An apex predator adapted to ${wp.biome}; its migrations are used to judge the harshness of a new season.`,`A territorial organism whose calls are treated as omens by the ${wp.tribes}.`,`A rare, dangerous species recorded in the Chapter's Trial Bestiary; hunting it without cause is forbidden.`][i]}));
 const battleCry=pick(r,['By oath and iron!','Let no light be lost!','Witness our resolve!','Into the long night!','We endure beyond death!','No fortress unbroken!','From silence, judgement!','The vow remains!']);
 const recruitment=`Each generation, Chaplains and Apothecaries visit the ${wp.tribes} to assess promising aspirants. Candidates must ${wp.trial}. Successful aspirants then undergo exhaustive physical and psychological screening; surviving the trial does not guarantee selection. Gene-seed implantation and training follow under Apothecary supervision.`;
 const initiation=`Before receiving their Chapter badge, neophytes observe the Vigil of ${pick(r,['Stone','Ash','The Silent Bell','The Seventh Gate','Iron Memory'])}: each must recount a moment of fear before their peers, then make a vow of service that is publicly recorded. The rite is a Chapter tradition, not a universal Codex Astartes requirement.`;
 const companies=settings.codex==='Strict'?10:settings.codex==='Broadly Compliant'?10:8;
 const org=settings.codex==='Strict'?'A broadly Codex-standard arrangement of ten companies, including veteran, battle, reserve and scout formations.':settings.codex==='Broadly Compliant'?'Ten companies retain recognisable Codex battlefield roles, but expeditionary detachments frequently combine squads under temporary war-councils.':'Eight permanent warhosts replace the conventional company sequence, though standard squads and officer ranks remain recognisable to Imperial allies.';
 const heroes=[{name:master,title:'Chapter Master',description:`Known as the Keeper of the ${pick(r,['Last Oath','Sealed Gate','Ashen Ledger'])}, he commands from the fortress-monastery and is feared for refusing victories bought through needless civilian sacrifice.`},{name:captain,title:`Captain of the ${roman(pick(r,[2,3,4,5]))} Company`,description:`Led the breach at ${pick(r,['Narthex Gate','Veyl Crossing','Damos Reach'])}, and is admired for weaving ${settings.doctrine.toLowerCase()} into unexpected theatres.`},{name:chaplain,title:'Reclusiarch',description:`Maintains the names of the Chapter’s lost and presides over its distinctive rites of induction and mourning.`}];
 const enemies=[{name:pick(r,threatNames),description:'A recurring enemy whose incursions have shaped the Chapter’s recent campaigns.'},{name:'Ork warbands of the Kordane Belt',description:'Raiding forces repeatedly threaten Imperial convoys and frontier worlds.'},{name:'Traitor Astartes renegades',description:'Disparate warbands, not a single invented founding Legion, encountered along the Chapter’s patrol routes.'}];
 const history=[
  {date:founded,event:'THE CHAPTER IS MUSTERED',detail:`The ${name} are raised ${distant}. ${settings.geneLine==='Unknown'?'Their progenitor is suppressed in the surviving records.':`Their gene-seed is recorded as stemming from the ${settings.geneLine}.`}`},
  {date:settings.founding==='Ultima Founding'?'M42':'Later in its recorded history',event:'THE BATTLE OF THE SUNDERED CHAIN',detail:`Under strength and far from reinforcement, the Chapter breaks a blockade at the ${pick(r,['Carthis','Vandros','Ossuary'])} transit corridor, preserving evacuating Imperial vessels.`},
  {date:'Campaign chronicle',event:'THE NIGHT OF NINE SIGNALS',detail:`Nine distress beacons sound across ${worldName}. Only three prove genuine. The Chapter uses its ${settings.doctrine.toLowerCase()} to expose the raiders behind the deception.`},
  {date:'Current era · M42',event:'THE LONG VIGIL',detail:`The Chapter guards the fractured approaches to its protectorate, tracking ${enemies[0].name} while struggling to replace decades of hard-won losses.`}
 ];
 const note= settings.founding==='Second Founding (speculative)'?'A newly invented Second Founding successor is deliberately speculative; its existence is not claimed as established canon.':settings.founding==='Unrecorded Founding'?'The absence of a recorded founding is a narrative device, not proof of any forbidden or traitor heritage.':settings.geneLine==='Unknown'?'Its progenitor remains unknown in this original story; no unsupported traitor gene-seed claim is made.':'Founding, homeworld, characters and campaigns below are original fan-created fiction.';
 return {id:`vf-${seed.toString(36)}`,seed,settings,name,epithet:pick(r,['THE UNBROKEN VIGIL','KEEPERS OF THE LAST LIGHT','THE OATH UNENDING','WARDENS OF THE OUTER NIGHT','A CHAPTER OF THE LONG WATCH']),battleCry,worldName,colour:col,sigil,accent,foundingDate:founded,geneNote:flaws.note,loreNote:note,worldTag:wp.tag,scene:wp.scene,fortress:worldStory.match(/(?:stands|travels within) ([^,.]+)/)?.[1]||'The Fortress-Monastery',culture,worldStory,wildlife,recruitment,initiation,organisation:org,companies,doctrineSummary:`Experts in ${dt[0]}, the Chapter places special emphasis on ${dt[1]}. Their preferred method is to ${dt[2]}.`,tactics:dt[0],heroes,enemies,history,relic:pick(r,relicNames),flaws:flaws.seed,createdAt:new Date().toISOString(),art:{}};
}
export function chapterSnapshot(c){return {geneLine:c.settings.geneLine,founding:c.settings.founding,homeworld:c.worldName,worldType:c.settings.worldType,doctrine:c.settings.doctrine,colour:c.settings.armour,temperament:c.settings.character,codex:c.settings.codex};}
