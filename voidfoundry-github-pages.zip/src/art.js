import {rng} from './generator.js';
const esc = s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

export function markSvg(symbol='spire',ink='#e9dcc4',size=72){
 const paths={
  spire:'<path d="M50 11 62 34 57 34 57 70 73 70 73 80 27 80 27 70 43 70 43 34 38 34Z"/><path d="M39 54H61M34 41H66" fill="none" stroke="currentColor" stroke-width="4"/>',
  blade:'<path d="M47 10 53 10 57 55 50 67 43 55Z"/><path d="M25 61H75L67 70H33Z"/><path d="M47 68H53V87H47Z"/>',
  star:'<path d="M50 10 58 38 87 50 58 59 50 89 42 59 13 50 42 38Z"/><circle cx="50" cy="50" r="10" fill="#171b20"/>',
  chalice:'<path d="M24 17H76L69 48Q66 60 55 63V76H70V83H30V76H45V63Q34 60 31 48Z"/><path d="M50 8V31" stroke="currentColor" stroke-width="3" fill="none"/>',
  wing:'<path d="M12 33Q41 26 50 55Q59 26 88 33L72 67 51 74 28 67Z"/><path d="M17 39 44 63M83 39 56 63" stroke="currentColor" stroke-width="4" fill="none"/>',
  flame:'<path d="M52 11Q57 37 39 45Q41 28 28 28Q32 48 26 56Q17 81 48 87Q80 87 74 55Q70 44 60 35Q63 51 53 56Q43 47 52 11Z"/><path d="M52 52Q59 72 49 77Q40 69 52 52Z" fill="#171b20"/>',
  skull:'<path d="M50 13C29 13 22 27 22 42C22 57 31 64 38 67V83H45V74H55V83H62V67C72 61 78 51 78 42C78 27 71 13 50 13Z"/><path d="M31 42 43 48 38 55 29 52ZM69 42 57 48 62 55 71 52Z" fill="#171b20"/><path d="M46 61H54" stroke="#171b20" stroke-width="4"/>',
  gate:'<path d="M17 18H83V82H67V38H33V82H17Z"/><path d="M37 53H63M50 40V81" stroke="currentColor" stroke-width="4" fill="none"/>'
 };
 return `<svg width="${size}" height="${size}" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" aria-label="Original ${esc(symbol)} Chapter icon"><g fill="${ink}" color="${ink}">${paths[symbol]||paths.spire}</g></svg>`;
}
export function shoulderSvg(c,{rank='battle-brother',company=4,squad=3,side='left',size=112}={}){
 const trim=c.colour.trim,base=c.colour.base; const rankText=rank.toLowerCase();
 const isVet=rankText.includes('veteran'),isCaptain=rankText.includes('captain'),isSergeant=rankText.includes('sergeant');
 const companyColours=['#eee8dc','#dcb96f','#c65a53','#6f9d74','#252b2d','#e38a4e','#9a71b2','#c6c5c0','#739fc2','#eee8dc'];
 const band=companyColours[(company-1)%companyColours.length];
 const symbol=side==='left'?markSvg(c.sigil,'#e9ddc4',54):`<svg width="55" height="55" viewBox="0 0 100 100"><path d="M15 24H85M15 50H85M15 76H85" stroke="#e9ddc4" stroke-width="8"/><text x="50" y="68" text-anchor="middle" fill="#e9ddc4" font-family="serif" font-size="43" font-weight="bold">${squad}</text></svg>`;
 let honours='';
 if(isSergeant)honours+='<path d="M31 45 68 26 105 45" stroke="#b6504e" stroke-width="7" fill="none"/>';
 if(isVet)honours+='<path d="M26 69Q20 40 40 27M110 69Q116 40 96 27" stroke="#f0ecdf" stroke-width="4" fill="none"/><path d="M26 51 18 43M31 39 28 30M110 51 118 43M105 39 108 30" stroke="#f0ecdf" stroke-width="4"/>';
 if(isCaptain)honours+='<path d="M35 34Q68 10 101 34" fill="none" stroke="#efd5a0" stroke-width="6"/><circle cx="68" cy="25" r="6" fill="#efd5a0"/>';
 return `<svg viewBox="0 0 136 136" width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg"><path d="M19 55C23 20 47 12 68 12S113 21 117 55L110 113H26Z" fill="${trim}"/><path d="M27 56C30 30 46 23 68 23S106 31 109 56L103 105H33Z" fill="${base}"/><path d="M35 48Q68 24 101 48" fill="none" stroke="${c.colour.light}" stroke-width="3" opacity=".65"/><path d="M27 103H109" stroke="${band}" stroke-width="9"/><foreignObject x="41" y="43" width="54" height="54">${symbol.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"')}</foreignObject>${honours}<text x="68" y="125" text-anchor="middle" fill="${trim}" font-weight="bold" font-size="10" letter-spacing="2">${isCaptain?'CAP':isVet?'VET':`CO. ${String(company).padStart(2,'0')}`}</text></svg>`;
}

export function marineSvg(c){
 const p=c.colour,trim=p.trim;
 const emblem=markSvg(c.sigil,'#e7dbbd',44);
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 570 720" class="marine-svg" role="img" aria-label="Original power-armoured warrior illustration in the Chapter colours">
 <defs>
  <linearGradient id="arm" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${p.light}"/><stop offset=".25" stop-color="${p.base}"/><stop offset=".67" stop-color="${p.shadow}"/><stop offset="1" stop-color="${p.base}"/></linearGradient>
  <linearGradient id="darkmetal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#7e8586"/><stop offset=".36" stop-color="#30383c"/><stop offset=".67" stop-color="#101820"/><stop offset="1" stop-color="#586268"/></linearGradient>
  <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#e9d5ac"/><stop offset=".46" stop-color="${trim}"/><stop offset="1" stop-color="#6d4d31"/></linearGradient>
  <filter id="eyeglow"><feGaussianBlur stdDeviation="4"/></filter>
  <filter id="softshade"><feGaussianBlur stdDeviation="12"/></filter>
 </defs>
 <ellipse cx="292" cy="678" rx="166" ry="24" fill="#050708" opacity=".7" filter="url(#softshade)"/>
 <!-- rear pack and vents -->
 <path d="M176 157 194 115 247 105 329 108 374 136 397 215 364 278 202 275 165 205Z" fill="url(#darkmetal)" stroke="#0b0f13" stroke-width="12"/>
 <path d="M160 118 215 114 222 188 170 199Z" fill="url(#darkmetal)" stroke="${trim}" stroke-width="5"/><path d="M363 113 406 137 400 199 362 182Z" fill="url(#darkmetal)" stroke="${trim}" stroke-width="5"/>
 <path d="M173 140H210M173 150H210M173 161H210M371 145H396M371 155H396M371 165H396" stroke="#8e999b" stroke-width="5"/>
 <!-- waist, legs rear -->
 <path d="M226 360 344 360 368 412 347 471 222 470 201 411Z" fill="url(#darkmetal)" stroke="#151b1e" stroke-width="9"/>
 <path d="M210 429 271 440 271 538 249 648 166 642 175 534Z" fill="url(#arm)" stroke="#11171a" stroke-width="12"/>
 <path d="M312 440 378 428 402 535 412 652 329 660 309 535Z" fill="url(#arm)" stroke="#11171a" stroke-width="12"/>
 <path d="M170 500 257 509 247 548 177 545Z" fill="url(#gold)"/><path d="M327 511 395 496 401 543 335 548Z" fill="url(#gold)"/>
 <path d="M169 530Q208 514 256 533L251 614Q208 631 169 616Z" fill="url(#arm)" stroke="#131719" stroke-width="8"/>
 <path d="M326 536Q367 510 407 531L412 616Q367 635 332 615Z" fill="url(#arm)" stroke="#131719" stroke-width="8"/>
 <path d="M174 608 249 609 251 665 223 693 131 693 141 661Z" fill="url(#arm)" stroke="#11171a" stroke-width="12"/>
 <path d="M331 608 410 607 435 668 433 693 344 693 328 662Z" fill="url(#arm)" stroke="#11171a" stroke-width="12"/>
 <path d="M138 689H223M345 689H430" stroke="${trim}" stroke-width="7"/>
 <path d="M185 554 193 595M347 551 363 593" stroke="${p.light}" opacity=".7" stroke-width="5"/>
 <!-- chest -->
 <path d="M209 206 367 208 394 292 371 396 295 437 206 391 178 293Z" fill="url(#arm)" stroke="#11171a" stroke-width="12"/>
 <path d="M209 245 281 268 291 371 212 362 195 288Z" fill="${p.base}" stroke="${p.shadow}" stroke-width="7"/>
 <path d="M360 245 290 268 291 371 367 360 383 289Z" fill="${p.base}" stroke="${p.shadow}" stroke-width="7"/>
 <path d="M210 248 282 273M368 247 297 271" stroke="${p.light}" opacity=".7" stroke-width="5"/>
 <path d="M253 356 327 355 323 395 291 408 258 395Z" fill="url(#gold)"/>
 <path d="M227 382 358 382" stroke="${trim}" stroke-width="7"/><path d="M233 416 346 416" stroke="#1b2026" stroke-width="14"/>
 <path d="M224 410 225 461 242 469 243 409M340 408 340 470 356 464 360 407" fill="url(#gold)" stroke="#171717" stroke-width="3"/>
 <!-- right arm behind gun -->
 <path d="M374 233 430 224 461 304 440 381 405 380 393 302Z" fill="url(#arm)" stroke="#11171a" stroke-width="12"/>
 <path d="M404 323 457 323 451 386 412 399Z" fill="url(#arm)" stroke="${trim}" stroke-width="6"/>
 <!-- shoulder plates -->
 <path d="M205 174Q171 141 122 162Q91 184 89 235L107 303 199 287 225 221Z" fill="url(#arm)" stroke="${trim}" stroke-width="12"/>
 <path d="M364 175Q409 138 457 169Q486 188 487 240L467 300 376 287 352 223Z" fill="url(#arm)" stroke="${trim}" stroke-width="12"/>
 <path d="M107 234Q133 175 197 202M373 199Q437 177 471 238" stroke="${p.light}" stroke-width="5" fill="none" opacity=".65"/>
 <!-- emblem, chest scroll and shoulder -->
 <foreignObject x="124" y="194" width="68" height="72">${emblem.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"')}</foreignObject>
 <path d="M225 303Q289 322 359 302" stroke="${trim}" stroke-width="9" fill="none"/>
 <path d="M242 310 250 348 335 348 346 312" fill="none" stroke="url(#gold)" stroke-width="5"/>
 <!-- left forearm -->
 <path d="M119 285 197 282 193 375 166 430 108 404 94 351Z" fill="url(#arm)" stroke="#11171a" stroke-width="11"/>
 <path d="M96 353 188 346 184 405 130 419Z" fill="url(#arm)" stroke="${trim}" stroke-width="6"/>
 <path d="M112 406 164 413 171 452 128 475 96 448Z" fill="url(#darkmetal)" stroke="#0f1518" stroke-width="9"/>
 <!-- helmet -->
 <path d="M225 162 235 101Q288 67 345 101L358 167 331 222 293 243 254 220Z" fill="url(#darkmetal)" stroke="#0c1115" stroke-width="12"/>
 <path d="M235 113Q285 83 341 111L339 159 323 190 283 216 247 189Z" fill="url(#arm)" stroke="${trim}" stroke-width="5"/>
 <path d="M251 155 286 165 269 178 239 177Z" fill="#0a1116"/><path d="M299 166 338 152 341 177 313 179Z" fill="#0a1116"/>
 <path d="M253 160 274 167 259 168Z" fill="#f63e32" filter="url(#eyeglow)"/><path d="M317 166 336 156 328 169Z" fill="#f63e32" filter="url(#eyeglow)"/>
 <path d="M253 161 274 167 259 168Z" fill="#f7a152"/><path d="M317 166 336 156 328 169Z" fill="#f7a152"/>
 <path d="M281 172 305 171 312 195 291 217 276 196Z" fill="url(#darkmetal)" stroke="${trim}" stroke-width="3"/>
 <path d="M276 191 307 190M278 198 307 197M283 206 303 205" stroke="#a1afb0" stroke-width="3"/>
 <path d="M255 105 288 93 330 105" fill="none" stroke="${p.light}" stroke-width="5"/>
 <!-- bolter across body, deliberately original design -->
 <g transform="translate(69 321) rotate(-10 224 80)">
  <path d="M105 70 414 70 446 83 453 107 431 121 107 121Z" fill="url(#darkmetal)" stroke="#10161a" stroke-width="10"/>
  <path d="M398 82 492 82 494 111 406 110Z" fill="#18252b" stroke="#080d11" stroke-width="7"/>
  <path d="M485 89H520V103H485Z" fill="url(#gold)"/><path d="M160 57H337V69H160Z" fill="#697277" stroke="#10151a" stroke-width="4"/>
  <path d="M201 117 266 117 265 180 220 186Z" fill="#252d31" stroke="#0b1217" stroke-width="8"/>
  <path d="M276 112 330 115 344 154 296 159Z" fill="#232c30" stroke="#10161a" stroke-width="7"/>
  <path d="M120 92H388" stroke="${trim}" stroke-width="5" opacity=".75"/>
  <path d="M362 83H388V107H362Z" fill="${p.base}" stroke="${trim}" stroke-width="2"/>
 </g>
 <path d="M111 413 142 404 164 422 164 457 132 465 103 444Z" fill="url(#darkmetal)" stroke="#12181b" stroke-width="8"/>
 <path d="M399 385 432 374 455 399 446 443 408 446 391 420Z" fill="url(#darkmetal)" stroke="#12181b" stroke-width="7"/>
 <!-- wear marks -->
 <path d="M177 578 208 564M349 572 381 561M113 249 144 234M442 258 465 248M353 320 371 313" stroke="#e5d2ab" stroke-width="2.4" opacity=".46"/>
 </svg>`;
}
export function landscapeSvg(c,{wide=true}={}){
 const r=rng(c.seed+91); const scene=c.scene;let stars='';for(let i=0;i<90;i++){const x=Math.round(r()*1000),y=Math.round(r()*480);stars+=`<circle cx="${x}" cy="${y}" r="${(r()*1.5+.2).toFixed(1)}" fill="#e6e0cb" opacity="${(r()*.65+.16).toFixed(2)}"/>`;}
 let fg='';let town='';
 if(scene==='hive'){for(let i=0;i<31;i++){const x=i*36-12,h=60+r()*290;town+=`<path d="M${x} 590V${590-h}L${x+15} ${560-h}L${x+25} ${590-h}V590" fill="#141c26" stroke="#627580" stroke-width=".6" opacity=".86"/><path d="M${x+11} ${590-h+20}V${590-h+50}" stroke="#e5ae69" opacity=".5"/>`;}}
 else if(scene==='ocean'){fg='<path d="M0 466Q130 436 258 472T522 472T770 470T1000 467V600H0Z" fill="#173d4a"/><path d="M0 495Q120 470 245 498T509 496T777 490T1000 494" fill="none" stroke="#8eaaa0" stroke-width="3" opacity=".3"/>';}
 else if(scene==='void'){fg='<path d="M0 510H1000V600H0Z" fill="#121c25"/><path d="M70 420 110 378 890 378 935 420V510H70Z" fill="#1a2530" stroke="#8a8b83" stroke-width="4"/><path d="M160 385H840M135 435H860" stroke="#b7a983" stroke-width="5" opacity=".5"/><circle cx="500" cy="452" r="43" fill="#0b0e16" stroke="#d3b585" stroke-width="8"/>';}
 else{for(let i=0;i<8;i++){let x=i*162-160,h=70+r()*210; const peak=x+65+r()*90; town+=`<path d="M${x} 535 ${peak} ${535-h} ${x+275} 535Z" fill="${i%2?'#182634':'#1f303b'}" opacity=".9"/>`;}}
 if(scene==='jungle'){for(let i=0;i<15;i++){const x=i*90+20,ht=r()*170+90;town+=`<path d="M${x} 560V${555-ht}" stroke="#111c20" stroke-width="10"/><ellipse cx="${x}" cy="${540-ht}" rx="${48+r()*34}" ry="29" fill="#142f2b"/>`;}}
 if(scene==='ice'){fg+='<path d="M0 505Q130 480 260 510Q390 487 520 511T1000 499V600H0Z" fill="#9bb7c1" opacity=".38"/>';}
 if(scene==='desert'){fg+='<path d="M0 480Q230 395 415 476T1000 460V600H0Z" fill="#624f40" opacity=".65"/>';}
 const planetHue=scene==='ice'?'#88c2cd':scene==='jungle'?'#729c89':scene==='desert'?'#c6956a':scene==='ocean'?'#65abb6':'#ae917a';
 return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 600" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Original procedurally generated scenery of ${esc(c.worldName)}"><defs><linearGradient id="sky" x2="0" y2="1"><stop stop-color="#0d131f"/><stop offset=".53" stop-color="#213442"/><stop offset="1" stop-color="#694c49"/></linearGradient><radialGradient id="planet"><stop stop-color="#f7c4a5" stop-opacity=".9"/><stop offset=".5" stop-color="${planetHue}"/><stop offset="1" stop-color="#1c2733"/></radialGradient><linearGradient id="fog" x2="0" y2="1"><stop stop-color="#a3a7a2" stop-opacity="0"/><stop offset="1" stop-color="#c99c81" stop-opacity=".25"/></linearGradient></defs><path fill="url(#sky)" d="M0 0H1000V600H0Z"/>${stars}<circle cx="${695+Math.round(r()*100)}" cy="${116+Math.round(r()*40)}" r="${100+Math.round(r()*35)}" fill="url(#planet)" opacity=".85"/><path d="M0 490Q200 430 380 482T780 466T1000 471V600H0Z" fill="#26333c"/>${town}${fg}<path d="M0 350H1000V600H0Z" fill="url(#fog)"/></svg>`;
}
export function beastSvg(c,index=0){
 let r=rng(c.seed+17+index*25);const hills='';const beasts=[
 `<path d="M75 173 122 146 159 127 177 102 203 110 216 147 251 151 278 181 266 187 241 177 232 213 218 213 212 173 151 173 139 215 124 215 126 172 101 188Z"/><path d="M175 111 168 78 181 101 200 96 222 75 207 114Z"/>`,
 `<path d="M50 171Q130 80 189 149Q240 77 334 165Q265 148 235 195L185 162Q122 214 50 171Z"/><path d="M184 160 175 205 194 208 205 166Z"/>`,
 `<path d="M53 188Q85 148 153 156L203 125 247 145 284 173 330 164 305 184 293 198 238 196 215 223 197 221 206 191 146 181 103 206 83 203 97 183Z"/><circle cx="256" cy="161" r="4" fill="#d1b48d"/>`
 ];
 return `<svg viewBox="0 0 380 260" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Concept silhouette for local fauna"><defs><linearGradient id="bs" x2="0" y2="1"><stop stop-color="#1b2830"/><stop offset="1" stop-color="#4a5b5e"/></linearGradient></defs><path d="M0 0H380V260H0Z" fill="url(#bs)"/><circle cx="300" cy="65" r="36" fill="#c7b997" opacity=".26"/><path d="M0 220Q87 189 192 231T380 207V260H0Z" fill="#1a292e"/><g fill="#0c151b" stroke="#35494b" stroke-width="3">${beasts[index%3]}</g><path d="M0 231Q130 212 380 224V260H0Z" fill="#101b20"/></svg>`;
}
export function armourChip(p,size=34){return `<span class="armour-chip" style="--chip-base:${p.base};--chip-light:${p.light};--chip-trim:${p.trim};width:${size}px;height:${size}px"></span>`;}
