import {fields,palette,blankPrefs,generateChapter} from './generator.js';
import {markSvg,marineSvg,landscapeSvg,beastSvg,shoulderSvg,armourChip} from './art.js';
const $=id=>document.getElementById(id);
const safe=s=>String(s??'').replace(/[&<>'"]/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[k]));
const toCss=s=>String(s??'').replace(/[^#0-9a-zA-Z,().% -]/g,'');
let prefs=blankPrefs(),mode='random',current=null,activeTab='overview',aiReady=false,toastTimer=null;
const STORAGE='voidfoundry_chapters_v1';
let saved=[];
try{const raw=JSON.parse(localStorage.getItem(STORAGE)||'[]');saved=Array.isArray(raw)?raw.slice(0,100):[]}catch{}
function getSave(){return saved.some(x=>x.id===current?.id)}
function store(){try{localStorage.setItem(STORAGE,JSON.stringify(saved))}catch{toast('Browser storage is full — export your Chapter instead.')}}
function notifySave(){ $('archiveCount').textContent=saved.length; $('saveButton').classList.toggle('saved',getSave());$('saveButton').querySelector('span').textContent=getSave()?'SAVED TO ARCHIVE':'SAVE CHAPTER';}
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('open');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('open'),3400)}
function makeFields(){
 $('creatorFields').innerHTML=fields.map((f,i)=>`<div class="creator-field"><label class="field-label" for="pref-${f.key}">${String(i+1).padStart(2,'0')} / ${safe(f.label).toUpperCase()}</label><div class="select-wrap"><select id="pref-${f.key}" data-pref="${f.key}">${f.options.map(x=>`<option value="${safe(x)}">${safe(x)}</option>`).join('')}</select></div></div>`).join('');
 $('creatorFields').querySelectorAll('select').forEach(el=>el.addEventListener('change',ev=>{prefs[ev.target.dataset.pref]=ev.target.value;if(mode==='random' && ev.target.value!=='Random')setMode('custom');}));
 updateFields();
}
function setMode(which){mode=which;$('randomMode').classList.toggle('active',which==='random');$('customMode').classList.toggle('active',which==='custom');if(which==='random')prefs=blankPrefs();updateFields();}
function updateFields(){for(const f of fields){const el=$(`pref-${f.key}`);el.value=prefs[f.key]||'Random';el.disabled=mode==='random';}}
function produce(seed=Math.floor(Math.random()*0xffffffff)){
 const next=generateChapter(mode==='random'?blankPrefs():prefs,seed);
 const custom=$('customName').value.trim();if(custom)next.name=custom;
 current=next;activeTab='overview';render();window.scrollTo({top:0,behavior:'smooth'});
}
function render(){
 const c=current;
 $('chapterName').textContent=c.name;
 $('chapterEpithet').textContent=c.epithet;
 $('chapterCry').textContent=`“${c.battleCry}”`;
 $('insigniaTitle').textContent=c.foundingDate.toUpperCase().slice(0,30);
 $('heroInsignia').innerHTML=markSvg(c.sigil,'#e7dac0',70);
 $('heroLandscape').innerHTML=c.art?.hero?`<img src="${safe(c.art.hero)}" alt="AI-generated original illustration for ${safe(c.name)}" style="width:100%;height:100%;object-fit:cover;object-position:center top"/>`:landscapeSvg(c);
 $('heroMarine').innerHTML=c.art?.hero?'':marineSvg(c);
 $('heroMarine').style.display=c.art?.hero?'none':'';
 $('dossierId').textContent=`ARCHIVE // ${c.id.slice(3).toUpperCase()}`;
 $('heroCoords').textContent=c.worldName.toUpperCase();
 const stats=[['GENE-SEED',c.settings.geneLine],['FOUNDING',c.settings.founding.replace(' (speculative)','')],['CHAPTER HOME',c.worldName],['COMBAT DOCTRINE',c.settings.doctrine]];
 $('chapterStats').innerHTML=stats.map(([l,v],i)=>`<div class="stat"><div class="stat-label">${safe(l)}</div><div class="stat-value ${i===1?'special':''}">${safe(v)}</div></div>`).join('');
 $('aiStatus').textContent=c.art?.hero?'✦ UNIQUE AI CONCEPT ART':'✧ ORIGINAL PROCEDURAL ART';
 document.querySelectorAll('[data-tab]').forEach(x=>{x.classList.toggle('active',x.dataset.tab===activeTab);x.setAttribute('aria-selected',String(x.dataset.tab===activeTab))});
 renderTab();notifySave();
}
const badge=(type,label)=>`<span class="protocol-type ${type}">◆ ${safe(label)}</span>`;
const card=(index,title,body,{full=false,dark=false,type='invented',label='ORIGINAL FAN LORE'}={})=>`<article class="info-card ${full?'full':''} ${dark?'dark':''}"><div class="card-top"><span class="card-index">${index}</span>${badge(type,label)}</div><h3>${safe(title)}</h3>${body}</article>`;
const para=text=>`<p>${safe(text)}</p>`;
function overview(c){
 const snap=[['GENE-SEED',c.settings.geneLine],['FOUNDING',c.foundingDate],['HOMEWORLD',c.worldName],['ARMOUR',c.settings.armour],['CODEX OBSERVANCE',c.settings.codex],['CHAPTER DISPOSITION',c.settings.character]];
 return `<div class="content-grid">
 ${card('01 / FOUNDING RECORD','A Chapter born in the shadow of war',`<div class="datum-list">${snap.map(([k,v])=>`<div class="datum"><dt>${safe(k)}</dt><dd>${safe(v)}</dd></div>`).join('')}</div><div class="divider-soft"></div>${para(c.loreNote)}`,{type:'caution',label:'FICTION / FLAGGED'})}
 ${card('02 / GENE-SEED','Bloodline & legacy',`${para(c.geneNote)}<div class="rule-banner"><strong>Canon-grounded basis</strong><br/>This background references established gene-seed traditions. The Chapter itself is an original creation.</div>`,{type:'canon',label:'CANON ANCHOR'})}
 ${card('03 / CUSTOMS & BELIEFS','The culture of the brotherhood',para(c.culture))}
 ${card('04 / MILITARY DOCTRINE','War is their sacrament',`${para(c.doctrineSummary)}<div class="mini-heading">COMMAND PRINCIPLE</div><p>Preferred discipline: <strong>${safe(c.tactics)}</strong>. Battle plans are adjusted to local conditions rather than treated as infallible ritual.</p>`,{dark:true})}
 ${card('05 / RECRUITMENT','The trial of the aspirant',`${para(c.recruitment)}<div class="divider-soft"></div><div class="mini-heading">INITIATION RITE</div>${para(c.initiation)}`,{full:true})}
 <div class="quote-card">“${safe(c.battleCry)}”<span>— TRADITIONAL CHAPTER BATTLE CRY</span></div>
 ${card('06 / CHAPTER COMMAND','The bearers of the oath',`<div class="feature-list">${c.heroes.map((h,i)=>`<div class="feature-row"><div class="feature-num">0${i+1}</div><div><b>${safe(h.name)} — ${safe(h.title)}</b><p>${safe(h.description)}</p></div></div>`).join('')}</div>`)}
 </div>`;
}
function homeworld(c){
 return `<div class="content-grid">
 <div class="full-bleed-art"><div class="art-landscape" style="width:100%;height:100%">${c.art?.world?`<img src="${safe(c.art.world)}" style="width:100%;height:100%;object-fit:cover" alt="Generated landscape of ${safe(c.worldName)}"/>`:landscapeSvg(c)}</div><span class="art-caption">✦ ${safe(c.worldName.toUpperCase())} / ORIGINAL WORLD CONCEPT</span><button type="button" class="art-generate-button" data-generate-art="world">✦ AI WORLD ART</button></div>
 ${card('01 / PLANETARY REGISTER',c.worldName,`${para(c.worldStory)}<div class="divider-soft"></div><div class="datum-list"><div class="datum"><dt>WORLD CLASSIFICATION</dt><dd>${safe(c.settings.worldType)}</dd></div><div class="datum"><dt>ENVIRONMENT</dt><dd>${safe(c.worldTag)}</dd></div></div>`)}
 ${card('02 / THE CHOSEN','Where warriors are made',`${para(c.recruitment)}<div class="divider-soft"></div>${para(c.initiation)}`)}
 ${card('03 / FAUNA BESTIARY','Creatures of the wild',`<p>Recorded in the Chapter’s local field archives. These invented species are unique to this generated setting.</p><div class="fauna-grid">${c.wildlife.map((w,i)=>`<div class="fauna-card"><div class="fauna-art">${c.art?.creatures?.[i]?`<img src="${safe(c.art.creatures[i])}" alt="Original AI concept art of ${safe(w.name)}" style="width:100%;height:100%;object-fit:cover"/>`:beastSvg(c,i)}</div><div class="fauna-copy"><h4>${safe(w.name)}</h4><p>${safe(w.description)}</p><button type="button" class="fauna-generate-button" data-generate-art="creature" data-creature-index="${i}">✦ ILLUSTRATE CREATURE</button></div></div>`).join('')}</div>`,{full:true})}
 </div>`;
}
function heraldry(c){
 const companyRoles=['VETERAN COMPANY','BATTLE COMPANY','BATTLE COMPANY','BATTLE COMPANY','BATTLE COMPANY','RESERVE COMPANY','RESERVE COMPANY','RESERVE COMPANY','RESERVE COMPANY','SCOUT / VANGUARD'];
 const companyBands=['#d7d9d1','#d5ad63','#b74343','#6f9a78','#222a2c','#dc7038','#8856a3','#c6bcab','#5d9cb5','#dad8d0'];
 const ranks=[['BATTLE-BROTHER',1],['SERGEANT',2],['VETERAN',3],['VETERAN SERGEANT',4],['CAPTAIN',5]];
 return `<div class="content-grid">
 ${card('01 / ARMOUR DESIGNATION','Livery of the Chapter',`<div style="display:flex;align-items:center;gap:17px;flex-wrap:wrap"><div>${shoulderSvg(c,{size:138})}</div><div><div class="mini-heading">COLOUR PALETTE</div><div class="colour-swatches">${[['PRIMARY',c.colour.base],['HIGHLIGHT',c.colour.light],['SHADOW',c.colour.shadow],['TRIM',c.colour.trim]].map(([a,b])=>`<div><div class="colour-swatch" style="background:${toCss(b)}"></div><div class="swatch-label">${a}</div></div>`).join('')}</div></div></div><div class="divider-soft"></div><p>The left pauldron carries the Chapter symbol. This Chapter’s original convention places company identity on the lower rim, with squad designations on the opposite shoulder or kneepad.</p>`)}
 ${card('02 / FIELD MARKINGS','Squad & rank conventions',`<p>Company distinctions below are generated adaptations of broadly familiar Codex conventions. They are <strong>this Chapter's chosen practice</strong>, not a rule all Space Marine Chapters must follow.</p><div class="rule-banner">${safe(c.organisation)}</div><div class="divider-soft"></div><p>Battleline, close-support, fire-support and veteran distinctions can be represented through dedicated squad icons. Officers may embellish those markings with personal honour devices.</p>`,{type:'canon',label:'CODEX-INSPIRED'})}
 ${card('03 / THE TEN COMPANIES','Company identification',`<div class="company-grid">${Array.from({length:c.companies},(_,i)=>`<div class="company"><div class="company-roman">${['I','II','III','IV','V','VI','VII','VIII','IX','X'][i]}</div>${shoulderSvg(c,{company:i+1,size:80})}<div class="company-role">${safe(c.companies===8?'WARHOST '+(i+1):companyRoles[i])}</div><div class="company-strip" style="background:${companyBands[i]}"></div></div>`).join('')}</div><p style="margin-top:20px">${c.companies===8?'This is an intentionally non-Codex eight-warhost organisation; standard ten-company roles do not all apply.':'The company roles are an illustrative Codex-inspired structure; individual Chapters may differ, and company colours can be adapted.'}</p>`,{full:true})}
 ${card('04 / RANK EXEMPLARS','Honours of command',`<div class="heraldry-gallery">${ranks.map(([rank,i])=>`<div class="heraldry-card">${shoulderSvg(c,{rank,company:i,size:100})}<b>${rank}</b><small>${i===5?'HONOUR DEVICE':`COMPANY ${i}`}</small></div>`).join('')}</div><div class="divider-soft"></div><p>For exact miniature painting, use this dossier as a Chapter-specific scheme rather than an official GW transfer guide. Helmet markings, squad icons and badges can be customised independently.</p>`,{full:true})}
 </div>`;
}
function chronicles(c){
 return `<div class="content-grid">
 ${card('01 / HISTORICAL RECORD','Chronicles of service',`<div class="timeline">${c.history.map(h=>`<div class="timeline-event"><div class="timeline-date">${safe(h.date).toUpperCase()}</div><h4>${safe(h.event)}</h4><p>${safe(h.detail)}</p></div>`).join('')}</div>`,{type:'invented',label:'FICTIONAL HISTORY'})}
 ${card('02 / NOTABLE PERSONNEL','Names in the rolls',`<div class="feature-list">${c.heroes.map((x,i)=>`<div class="feature-row"><div class="feature-num">0${i+1}</div><div><b>${safe(x.name)}</b><p><strong>${safe(x.title)}</strong> — ${safe(x.description)}</p></div></div>`).join('')}</div>`)}
 ${card('03 / RECORDED ADVERSARIES','Enemies of the oath',`<div class="feature-list">${c.enemies.map((x,i)=>`<div class="feature-row"><div class="feature-num">0${i+1}</div><div><b>${safe(x.name)}</b><p>${safe(x.description)}</p></div></div>`).join('')}</div>`)}
 ${card('04 / RELIC OF OFFICE','A sacred inheritance',`<div class="quote-card">${safe(c.relic)}</div><div class="divider-soft"></div><p>This named relic is an original piece of Chapter folklore. Its precise origin is debated in the Apothecarion and Reclusiam.</p>`)}
 </div>`;
}
function renderTab(){const c=current;if(!c)return;const pages={overview,homeworld,heraldry,chronicles};$('tabContent').innerHTML=(pages[activeTab]||overview)(c);}
function saveCurrent(){if(!current)return;const pos=saved.findIndex(x=>x.id===current.id);if(pos>=0){toast('Already in your archive.');return;} saved.unshift(structuredClone(current));saved=saved.slice(0,80);store();notifySave();toast(`${current.name} added to your archive.`);}
function openArchive(){renderArchive();openModal('archive')}
function renderArchive(){
 $('savedChapters').innerHTML=saved.length?saved.map(x=>`<div class="saved-card" data-id="${safe(x.id)}"><div>${markSvg(x.sigil,'#d4c49f',40)}</div><div class="saved-card-info"><div class="saved-card-name">${safe(x.name)}</div><div class="saved-card-meta">${safe(x.settings?.geneLine||'Unknown')} · ${safe(x.worldName||'Unrecorded')} · ${safe(x.settings?.armour||'')}</div></div><div class="saved-card-actions"><button type="button" data-action="open" data-id="${safe(x.id)}">OPEN</button><button type="button" class="delete" data-action="delete" data-id="${safe(x.id)}" aria-label="Delete ${safe(x.name)}">×</button></div></div>`).join(''):`<div class="empty-state">✦<br/>NO CHAPTERS YET RECORDED<br/>Forge a Chapter and save it to begin your archive.</div>`;
}
function openModal(name){const root=$(`${name}Overlay`);root.classList.add('open');root.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';}
function closeModal(name){const root=$(`${name}Overlay`);root.classList.remove('open');root.setAttribute('aria-hidden','true');document.body.style.overflow='';}
async function shareChapter(){
 const config={seed:current.seed,prefs:current.settings,name:current.name};
 const bytes=new TextEncoder().encode(JSON.stringify(config));const b64=btoa(Array.from(bytes,b=>String.fromCharCode(b)).join('')).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
 const url=new URL(location.href);url.searchParams.set('chapter',b64);const text=location.protocol==='file:'?`VOIDFOUNDRY CHAPTER SEED: ${b64}`:url.toString();
 try{await navigator.clipboard.writeText(text);toast(location.protocol==='file:'?'Chapter seed copied. Publish the site for shareable URLs.':'Shareable Chapter seed link copied.')}catch{window.prompt('Copy your Chapter seed link:',text);}
}
function exportDossier(){
 const c=current;const all=[overview(c),homeworld(c),heraldry(c),chronicles(c)].join('');
 const html=`<!doctype html><html lang="en-GB"><head><meta charset="utf-8"><title>${safe(c.name)} — Voidfoundry dossier</title><style>body{max-width:1000px;margin:35px auto;font:13px/1.7 Arial,sans-serif;color:#d9ddda;background:#121a1c;padding:20px}header{border-bottom:3px solid #cbb17d;margin-bottom:30px}h1{font:800 66px Impact,Arial,sans-serif;margin:0;letter-spacing:1px}h2,h3,h4{font-family:Impact,Arial,sans-serif;text-transform:uppercase;letter-spacing:.6px}h3{font-size:26px}p{line-height:1.85}.content-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px}.info-card,.fauna-card,.heraldry-card,.company{border:1px solid #596560;padding:16px;break-inside:avoid}.info-card.full{grid-column:1/-1}.protocol-type,.mini-heading,.card-index{font-size:10px;font-weight:bold;color:#ccb17e;letter-spacing:1px}.card-top{display:flex;justify-content:space-between}.datum-list{display:grid;grid-template-columns:1fr 1fr;gap:12px}.datum dt{font-size:9px;color:#9ba9a3}.datum dd{margin:0;font-weight:bold;font-size:17px}.fauna-grid,.heraldry-gallery,.company-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.fauna-art svg{max-width:100%}.company svg{max-width:100%}.full-bleed-art{grid-column:1/-1;height:230px;overflow:hidden;position:relative}.full-bleed-art svg{width:100%;height:100%}.art-caption{position:absolute;bottom:12px;left:12px;color:white;background:#121a1c;padding:6px}.timeline-event{border-left:2px solid #bba278;padding:0 16px 16px;margin-left:9px}.timeline-date{color:#bba278}.quote-card{border-left:3px solid #cbb17d;padding:20px;font-size:24px}.colour-swatches{display:flex;gap:10px}.colour-swatch{width:45px;height:55px}.swatch-label{font-size:8px}.feature-row{padding:8px 0;border-bottom:1px solid #39423e;display:flex;gap:10px}.feature-num{color:#ccb17e}.rule-banner{border:1px solid #596560;padding:12px}.divider-soft{margin:16px 0;border-top:1px solid #596560}.company-strip{height:5px}.company-role{font-size:10px}@media print{body{background:#fff;color:#111;margin:0;padding:0}header{break-after:avoid}.info-card,.fauna-card,.heraldry-card,.company{border-color:#888}h1{font-size:50px}p{color:#222}.content-grid{gap:9px} .full-bleed-art{height:180px}.protocol-type,.card-index{color:#866638}}</style></head><body><header><div>VOIDFOUNDRY / UNOFFICIAL CHAPTER DOSSIER</div><h1>${safe(c.name)}</h1><p>${safe(c.epithet)} &nbsp; | &nbsp; ${safe(c.battleCry)}</p><p>${safe(c.loreNote)}</p></header>${all}<hr><small>Original fan-created Chapter. No Games Workshop endorsement or official canon status is claimed. Use your browser's Print → Save as PDF to create a PDF copy.</small></body></html>`;
 const blob=new Blob([html],{type:'text/html;charset=utf-8'});const link=document.createElement('a');link.href=URL.createObjectURL(blob);link.download=c.name.toLowerCase().replace(/[^a-z0-9]+/g,'-')+'-chapter-dossier.html';document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(link.href),1500);toast('Dossier downloaded as printable HTML.');
}
async function serverStatus(){try{const r=await fetch('/api/status',{signal:AbortSignal.timeout(2500)});if(!r.ok)throw Error();const s=await r.json();aiReady=!!s.enabled; if(aiReady){$('connectionLabel').textContent='AI FORGE CONNECTED';$('imageButton').title='Creates a new original illustration using the configured AI key';}
 }catch{} }
async function generateAIArt(kind='hero', index=0){
 if(!aiReady){toast('AI artwork needs a server-side OPENAI_API_KEY. Original procedural art works now.');return;}
 const requestChapter=current; const btn=kind==='hero'?$('imageButton'):null;
 if(btn){btn.classList.add('is-loading');btn.querySelector('span').textContent='ILLUSTRATING...';}
 toast(`Generating original ${kind==='hero'?'Chapter':kind==='world'?'world':'creature'} artwork…`);
 try{
  const res=await fetch('/api/art',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chapter:requestChapter,kind,index})});
  const data=await res.json();if(!res.ok)throw Error(data.error||'AI image generation failed');
  if(kind==='creature'){requestChapter.art={...(requestChapter.art||{}),creatures:{...(requestChapter.art?.creatures||{}),[index]:data.url}};}
  else requestChapter.art={...(requestChapter.art||{}),[kind]:data.url};
  const savedIndex=saved.findIndex(x=>x.id===requestChapter.id);if(savedIndex!==-1){saved[savedIndex]=structuredClone(requestChapter);store();}
  if(current===requestChapter)render();
  toast(`Original ${kind} artwork created.`);
 }catch(err){toast(err.message||'Unable to generate artwork.');}
 finally{if(btn){btn.classList.remove('is-loading');btn.querySelector('span').textContent='GENERATE AI ART';}}
}

async function enhanceLore(){
 if(!aiReady){toast('AI-written lore requires a configured server API key.');return;}
 const btn=$('enhanceButton');btn.classList.add('is-loading');btn.querySelector('span').textContent='ENHANCING...';
 try{const res=await fetch('/api/chapter',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chapter:current})});const data=await res.json();if(!res.ok)throw Error(data.error||'AI writing failed');const allow=['culture','worldStory','recruitment','initiation','organisation','doctrineSummary','loreNote','relic','wildlife','heroes','enemies','history'];for(const k of allow){if(data.chapter[k]!==undefined)current[k]=data.chapter[k];}const pos=saved.findIndex(x=>x.id===current.id);if(pos!==-1){saved[pos]=structuredClone(current);store();}render();toast('Chapter dossier enhanced with AI-written original lore.');}
 catch(err){toast(err.message||'Could not enhance Chapter lore.');}
 finally{btn.classList.remove('is-loading');btn.querySelector('span').textContent='ENHANCE LORE';}
}
function initialize(){
 makeFields();
 $('randomMode').addEventListener('click',()=>setMode('random'));
 $('customMode').addEventListener('click',()=>setMode('custom'));
 $('resetFields').addEventListener('click',()=>{prefs=blankPrefs();$('customName').value='';updateFields();toast('All Chapter parameters reset.');});
 $('forgeButton').addEventListener('click',()=>produce());
 $('saveButton').addEventListener('click',saveCurrent);
 $('shareButton').addEventListener('click',shareChapter);
 $('downloadButton').addEventListener('click',exportDossier);
 $('imageButton').addEventListener('click',()=>generateAIArt('hero'));
 $('tabContent').addEventListener('click',e=>{const btn=e.target.closest('[data-generate-art]');if(btn)generateAIArt(btn.dataset.generateArt,Number(btn.dataset.creatureIndex||0));});
 document.querySelectorAll('[data-tab]').forEach(el=>el.addEventListener('click',()=>{activeTab=el.dataset.tab;render();}));
 document.querySelectorAll('[data-nav]').forEach(el=>el.addEventListener('click',()=>{const name=el.dataset.nav;if(name==='archive')openArchive();else if(name==='protocol')openModal('protocol');else{document.getElementById('forge').scrollIntoView({behavior:'smooth'});}}));
 document.querySelectorAll('[data-close]').forEach(el=>el.addEventListener('click',()=>closeModal(el.dataset.close)));
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeModal('archive');closeModal('protocol');}});
 $('savedChapters').addEventListener('click',e=>{const btn=e.target.closest('[data-action]');if(!btn)return;const id=btn.dataset.id;if(btn.dataset.action==='open'){const item=saved.find(x=>x.id===id);if(item){current=structuredClone(item);activeTab='overview';render();closeModal('archive');window.scrollTo({top:0,behavior:'smooth'});toast(`${current.name} restored.`);}}else if(btn.dataset.action==='delete'){const item=saved.find(x=>x.id===id);if(item&&!confirm(`Permanently remove ${item.name} from this browser's archive?`))return;saved=saved.filter(x=>x.id!==id);store();renderArchive();notifySave();toast('Chapter removed from archive.');}});
 // More complete AI lore toggle, provided beside the image tool.
 const aiBtn=document.createElement('button');aiBtn.id='enhanceButton';aiBtn.type='button';aiBtn.className='action-btn ai-btn';aiBtn.innerHTML='✧ <span>ENHANCE LORE</span>';$('imageButton').insertAdjacentElement('beforebegin',aiBtn);aiBtn.addEventListener('click',enhanceLore);
 try{const raw=new URLSearchParams(location.search).get('chapter');if(raw&&raw.length<2000){const dec=atob(raw.replace(/-/g,'+').replace(/_/g,'/'));const config=JSON.parse(new TextDecoder().decode(Uint8Array.from(dec,x=>x.charCodeAt(0))));if(Number.isSafeInteger(config.seed)&&config.seed>=0){const seed=generateChapter(config.prefs,config.seed);current=seed;if(typeof config.name==='string'&&config.name.length<=54){current.name=config.name;$('customName').value=config.name;}prefs=Object.fromEntries(fields.map(f=>[f.key,f.options.includes(config.prefs?.[f.key])?config.prefs[f.key]:'Random']));setMode('custom');}}}catch{}
 if(!current)current=generateChapter({geneLine:'Imperial Fists',founding:'Ultima Founding',worldType:'Ice World',armour:'Deep Teal',doctrine:'Siege Warfare',character:'Stoic',codex:'Broadly Compliant'},401249);
 render();serverStatus();
}
initialize();
